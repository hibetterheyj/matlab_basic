function a = not_smallest(x,y,z)
if x >= y || x >= z
a = 1;
else
a = 0;
end
