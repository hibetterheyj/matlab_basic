function guess_my_number(x)
if x == 42
	fprintf('Congrats! You guessed my number!\n');
else
    fprintf('Too big. Try again.\n')
end



